package com.example.hexadecimalcalculator.calculation;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class BaseConverter {

    public double convertHexadecimalToDecimal(String hexadecimalString) {
        int indexOfDot = -1;
        for (int i = 0; i < hexadecimalString.length(); i++) {
            if (hexadecimalString.charAt(i) == '.') {
                indexOfDot = i;
                break;
            }
        }
        double decimalValue = 0;
        if (indexOfDot != -1) {
            if (indexOfDot != 0) {
                decimalValue = Long.parseLong(hexadecimalString.substring(0, indexOfDot), 16);
            }
            long base = 16L;
            for (int i = indexOfDot + 1; i < hexadecimalString.length(); i++) {
                char hexadecimalDigit = hexadecimalString.charAt(i);
                double hexadecimalDigitValue = Integer.parseInt(String.valueOf(hexadecimalDigit), 16);
                decimalValue += (hexadecimalDigitValue / (double) base);
                base *= 16L;
            }
        } else {
            decimalValue = Long.parseLong(hexadecimalString, 16);
        }
        return decimalValue;
    }

    public String convertDecimalToHexadecimal(double decimalNumber) {
        DecimalFormat df = new DecimalFormat("#.###");
        df.setRoundingMode(RoundingMode.CEILING);
        decimalNumber = Double.parseDouble(df.format(decimalNumber));

        String hexadecimalString = Long.toHexString((long) decimalNumber);
        decimalNumber -= (long) decimalNumber;

        if (decimalNumber == 0.0) {
            return hexadecimalString;
        }
        hexadecimalString += ".";
        for (int i = 0; i < 3; i++) {
            decimalNumber *= 16;
            hexadecimalString += Long.toHexString((long) decimalNumber);
            decimalNumber -= (long) decimalNumber;
        }

        return hexadecimalString;
    }
}
