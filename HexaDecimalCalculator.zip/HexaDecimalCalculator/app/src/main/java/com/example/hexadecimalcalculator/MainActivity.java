package com.example.hexadecimalcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.hexadecimalcalculator.calculation.BaseConverter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView txtview;
    private Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0;
    private Button ba, bb, bc, bd, be, bf;
    private Button bplus, bmin, beq, bmul, bdiv, bpoint;
    private Button bsin, bcos, bpow, bclr;
    private double temp = 0.0;
    private int choice = -1;

    private String inputString = "";
    private double result = 0.0;
    private BaseConverter baseConverter = new BaseConverter();

    private void calculation() {
        if (choice == -1) {
            result = temp;
        } else if (choice == 0) {
            result += temp;
        } else if (choice == 1) {
            result -= temp;
        } else if (choice == 2) {
            result *= temp;
        } else if (choice == 3) {
            result /= temp;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);

        ba = findViewById(R.id.ba);
        bb = findViewById(R.id.bb);
        bc = findViewById(R.id.bc);
        bd = findViewById(R.id.bd);
        be = findViewById(R.id.be);
        bf = findViewById(R.id.bf);

        bplus = findViewById(R.id.bplus);
        bmin = findViewById(R.id.bmin);
        beq = findViewById(R.id.beq);
        bmul = findViewById(R.id.bmul);
        bdiv = findViewById(R.id.bdiv);
        bpoint = findViewById(R.id.bpoint);

        bsin = findViewById(R.id.bsin);
        bcos = findViewById(R.id.bcos);
        bpow = findViewById(R.id.bpow);
        bclr = findViewById(R.id.bclr);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        b0.setOnClickListener(this);

        ba.setOnClickListener(this);
        bb.setOnClickListener(this);
        bc.setOnClickListener(this);
        bd.setOnClickListener(this);
        be.setOnClickListener(this);
        bf.setOnClickListener(this);

        bplus.setOnClickListener(this);
        bmin.setOnClickListener(this);
        beq.setOnClickListener(this);
        bmul.setOnClickListener(this);
        bdiv.setOnClickListener(this);
        bpoint.setOnClickListener(this);

        bsin.setOnClickListener(this);
        bcos.setOnClickListener(this);
        bpow.setOnClickListener(this);
        bclr.setOnClickListener(this);

        txtview = findViewById(R.id.txtview);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.b0:
                inputString = txtview.getText().toString();
                inputString = inputString + "0";
                txtview.setText(inputString);
                break;
            case R.id.b1:
                inputString = txtview.getText().toString();
                inputString = inputString + "1";
                txtview.setText(inputString);
                break;
            case R.id.b2:
                inputString = txtview.getText().toString();
                inputString = inputString + "2";
                txtview.setText(inputString);
                break;
            case R.id.b3:
                inputString = txtview.getText().toString();
                inputString = inputString + "3";
                txtview.setText(inputString);
                break;
            case R.id.b4:
                inputString = txtview.getText().toString();
                inputString = inputString + "4";
                txtview.setText(inputString);
                break;
            case R.id.b5:
                inputString = txtview.getText().toString();
                inputString = inputString + "5";
                txtview.setText(inputString);
                break;
            case R.id.b6:
                inputString = txtview.getText().toString();
                inputString = inputString + "6";
                txtview.setText(inputString);
                break;
            case R.id.b7:
                inputString = txtview.getText().toString();
                inputString = inputString + "7";
                txtview.setText(inputString);
                break;
            case R.id.b8:
                inputString = txtview.getText().toString();
                inputString = inputString + "8";
                txtview.setText(inputString);
                break;
            case R.id.b9:
                inputString = txtview.getText().toString();
                inputString = inputString + "9";
                txtview.setText(inputString);
                break;


            case R.id.ba:
                inputString = txtview.getText().toString();
                inputString = inputString + "a";
                txtview.setText(inputString);
                break;
            case R.id.bb:
                inputString = txtview.getText().toString();
                inputString = inputString + "b";
                txtview.setText(inputString);
                break;
            case R.id.bc:
                inputString = txtview.getText().toString();
                inputString = inputString + "c";
                txtview.setText(inputString);
                break;
            case R.id.bd:
                inputString = txtview.getText().toString();
                inputString = inputString + "d";
                txtview.setText(inputString);
                break;
            case R.id.be:
                inputString = txtview.getText().toString();
                inputString = inputString + "e";
                txtview.setText(inputString);
                break;
            case R.id.bf:
                inputString = txtview.getText().toString();
                inputString = inputString + "f";
                txtview.setText(inputString);
                break;


            case R.id.bsin:
                inputString = txtview.getText().toString();
                if (inputString.equals("")) {
                    inputString = "0";
                }
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                result = Math.sin((Math.PI * temp) / 180.0);
                choice = 5;
                txtview.setText(baseConverter.convertDecimalToHexadecimal(result));
                break;
            case R.id.bcos:
                inputString = txtview.getText().toString();
                if (inputString.equals("")) {
                    inputString = "0";
                }
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                result = Math.cos((Math.PI * temp) / 180.0);
                choice = 6;
                txtview.setText(inputString);
                break;
            case R.id.bpow:
                inputString = txtview.getText().toString();
                if (inputString.equals("0")) {
                    inputString = "0";
                }
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                inputString = "";
                txtview.setText(inputString);
                choice = 7;
                break;
            case R.id.bclr:
                inputString = txtview.getText().toString();
                inputString = "";
                txtview.setText(inputString);
                result = 0;
                choice = -1;
                break;


            case R.id.bplus:
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                calculation();
                choice = 0;
                txtview.setText("");
                break;
            case R.id.bmin:
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                calculation();
                choice = 1;
                txtview.setText("");
                break;
            case R.id.bmul:
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                calculation();
                choice = 2;
                txtview.setText("");
                break;
            case R.id.bdiv:
                temp = baseConverter.convertHexadecimalToDecimal(inputString);
                calculation();
                choice = 3;
                txtview.setText("");
                break;
            case R.id.bpoint:
                inputString = txtview.getText().toString();
                inputString = inputString + ".";
                txtview.setText(inputString);
                break;


            case R.id.beq:
                if (inputString.equals("")) {
                    inputString = "0";
                }

                if (choice == -1) {
                    result = baseConverter.convertHexadecimalToDecimal(inputString);
                } else if (choice == 0) {
                    result += baseConverter.convertHexadecimalToDecimal(inputString);
                } else if (choice == 1) {
                    result -= baseConverter.convertHexadecimalToDecimal(inputString);
                } else if (choice == 2) {
                    result *= baseConverter.convertHexadecimalToDecimal(inputString);
                } else if (choice == 3) {
                    result /= baseConverter.convertHexadecimalToDecimal(inputString);
                }
                else if (choice == 7) {
                    if (inputString.equals("")) {
                        inputString = "0";
                    }
                    result = Math.pow(temp, baseConverter.convertHexadecimalToDecimal(inputString));
                }
                txtview.setText(baseConverter.convertDecimalToHexadecimal(result));
//                temp = 0.0;
//                choice = -1;

                break;
        }
    }
}